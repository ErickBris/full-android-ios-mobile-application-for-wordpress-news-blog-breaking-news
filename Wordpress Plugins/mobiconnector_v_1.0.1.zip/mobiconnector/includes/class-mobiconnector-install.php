<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class MobiConnectorInstall{
		
	public function __construct() {
		
	}
	
}
$MobiConnectorInstall = new MobiConnectorInstall();
?>