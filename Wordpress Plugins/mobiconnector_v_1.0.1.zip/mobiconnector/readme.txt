Thêm Post một số thông số
- tổng bình luận
- Ảnh feature
- thông tin tác giả
- Tổng số lượt xem
- Tăng lượt view khi xem trên mobile
_ fix cross domain